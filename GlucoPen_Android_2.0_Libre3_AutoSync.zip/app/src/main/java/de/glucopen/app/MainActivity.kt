package de.glucopen.app

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.provider.Settings
import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.os.Handler
import android.os.Looper
import net.cacheux.nvplib.data.PenResult
import net.cacheux.nvplib.nfc.NfcController
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import kotlin.math.max
import kotlin.math.min
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.GZIPInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import androidx.work.PeriodicWorkRequestBuilder
import java.util.concurrent.TimeUnit
import org.json.JSONObject

data class GlucosePoint(val time: Long, val value: Double)
data class Dose(val time: Long, val units: Double, val source: String)

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    private var onTagDetected: ((Tag) -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val nfcController by lazy {
        NfcController(this) { action ->
            Thread(action, "GlucoPen-NovoPen-NFC").start()
        }
    }

    private val csvPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                val result = AppStore.importLibreCsv(text)
                AppStore.status = result
            } ?: run {
                AppStore.status = "LibreView-Import: Datei konnte nicht geöffnet werden"
            }
        } catch (e: Exception) {
            AppStore.status = "LibreView-Import fehlgeschlagen: ${e.message ?: "unbekannter Fehler"}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        AppStore.init(applicationContext)
        LibreSyncWorker.schedule(applicationContext)

        setContent {
            GlucoPenApp(
                onNfc = { onTagDetected = it },
                onImportLibre = { csvPicker.launch(arrayOf("*/*")) }
            )
        }
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (nfcAdapter?.isEnabled == true) {
            nfcController.monitorNfc(
                onTagDetected = { tag ->
                    mainHandler.post {
                        AppStore.nfcInfo = "NovoPen/NFC erkannt • " +
                            tag.techList.joinToString(", ") { it.substringAfterLast(".") }
                        AppStore.status = "NovoPen wird gelesen …"
                    }
                },
                onDataRead = { result ->
                    mainHandler.post { handleNovoPenResult(result) }
                },
                onError = { error ->
                    mainHandler.post {
                        AppStore.status = "NovoPen-Lesen fehlgeschlagen: ${error.message ?: "NFC-Fehler"}"
                    }
                }
            )
        }
    }

    override fun onPause() {
        nfcController.stopNfc()
        super.onPause()
    }

    private fun handleNovoPenResult(result: PenResult) {
        when (result) {
            is PenResult.Success -> {
                val data = result.data
                val imported = data.doseList.map {
                    Dose(it.time, it.units.toDouble(), "NovoPen Echo Plus/6")
                }
                AppStore.doses.removeAll { it.source.startsWith("NovoPen") }
                AppStore.doses.addAll(imported.sortedBy { it.time })
                AppStore.nfcInfo = "NovoPen gelesen • ${data.model} • ${data.serial}"
                AppStore.status = "NovoPen-Import erfolgreich: ${imported.size} Insulingaben"
            }
            is PenResult.Failure -> {
                AppStore.status = "NovoPen-Lesen fehlgeschlagen: ${result.message}"
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_TECH_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action) {
            intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)?.let {
                AppStore.nfcInfo = describeTag(it)
                onTagDetected?.invoke(it)
            }
        }
    }

    private fun describeTag(tag: Tag): String {
        val tech = tag.techList.joinToString(", ") { it.substringAfterLast(".") }
        return "NFC erkannt • $tech"
    }
}

object AppStore {
    private lateinit var appContext: Context
    private const val PREFS = "glucopen_data"
    private const val GLUCOSE_JSON = "glucose_json"
    var libreStatus by mutableStateOf("Libre 3: nicht verbunden")
    var libreLastSync by mutableStateOf("Noch keine automatische Synchronisation")

    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        loadPersistedGlucose()
        libreStatus = SecureStore(appContext).get("libre_email")?.let { "Libre 3: verbunden ($it)" } ?: "Libre 3: nicht verbunden"
    }

    val glucose = mutableStateListOf(
        GlucosePoint(System.currentTimeMillis() - 30 * 60_000L, 119.0),
        GlucosePoint(System.currentTimeMillis() - 15 * 60_000L, 121.0),
        GlucosePoint(System.currentTimeMillis(), 119.0)
    )
    val doses = mutableStateListOf<Dose>()
    var nfcInfo by mutableStateOf("Noch kein NFC-Gerät erkannt")
    var status by mutableStateOf("Bereit")

    private fun loadPersistedGlucose() {
        if (!::appContext.isInitialized) return
        val raw = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(GLUCOSE_JSON, null) ?: return
        try {
            val arr = org.json.JSONArray(raw)
            val loaded = ArrayList<GlucosePoint>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                loaded.add(GlucosePoint(o.getLong("time"), o.getDouble("value")))
            }
            if (loaded.isNotEmpty()) {
                glucose.clear()
                glucose.addAll(loaded.sortedBy { it.time })
            }
        } catch (_: Exception) { }
    }

    fun persistGlucose() {
        if (!::appContext.isInitialized) return
        val arr = org.json.JSONArray()
        glucose.forEach { p ->
            arr.put(org.json.JSONObject().put("time", p.time).put("value", p.value))
        }
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(GLUCOSE_JSON, arr.toString()).apply()
    }

    fun addDose(units: Double) {
        doses.add(Dose(System.currentTimeMillis(), units, "Manuell"))
        status = "Insulin gespeichert"
    }

    fun importLibreCsv(csv: String): String {
        // LibreView exports usually have one metadata line followed by the real header.
        // We locate the header by its column names instead of assuming a fixed line number.
        val allLines = csv.lineSequence().toList()
        val headerIndex = allLines.indexOfFirst { line ->
            line.contains("Gerätezeitstempel", ignoreCase = true) &&
                (line.contains("Glukosewert-Verlauf", ignoreCase = true) ||
                 line.contains("Historic Glucose", ignoreCase = true))
        }
        if (headerIndex < 0) {
            return "LibreView-Import: Keine gültige LibreView-Kopfzeile gefunden"
        }

        val header = parseCsvLine(allLines[headerIndex])
        val timestampIndex = header.indexOfFirst { it.trim().equals("Gerätezeitstempel", true) || it.trim().equals("Device Timestamp", true) }
        val historicIndex = header.indexOfFirst { it.contains("Glukosewert-Verlauf", true) || it.contains("Historic Glucose", true) }
        val scanIndex = header.indexOfFirst { it.contains("Glukose-Scan", true) || it.contains("Scan Glucose", true) }

        if (timestampIndex < 0 || (historicIndex < 0 && scanIndex < 0)) {
            return "LibreView-Import: Benötigte Glukose-Spalten fehlen"
        }

        val parsed = ArrayList<GlucosePoint>(allLines.size)
        val formats = listOf(
            "dd-MM-yyyy HH:mm",
            "dd.MM.yyyy HH:mm",
            "yyyy-MM-dd HH:mm",
            "dd-MM-yyyy HH:mm:ss",
            "dd.MM.yyyy HH:mm:ss",
            "yyyy-MM-dd HH:mm:ss"
        )

        for (i in headerIndex + 1 until allLines.size) {
            val line = allLines[i]
            if (line.isBlank()) continue
            val parts = parseCsvLine(line)
            if (timestampIndex >= parts.size) continue

            val rawValue = listOfNotNull(
                if (historicIndex >= 0 && historicIndex < parts.size) parts[historicIndex] else null,
                if (scanIndex >= 0 && scanIndex < parts.size) parts[scanIndex] else null
            ).firstOrNull { it.trim().isNotEmpty() && it.trim() != "0" }

            val value = rawValue?.trim()?.replace("\"", "")?.replace(',', '.')?.toDoubleOrNull()
            if (value == null || value !in 20.0..600.0) continue

            val timeText = parts[timestampIndex].trim().trim('"')
            val time = parseDate(timeText, formats) ?: continue
            parsed.add(GlucosePoint(time, value))
        }

        if (parsed.isEmpty()) {
            return "LibreView-Import: 0 Glukosewerte erkannt. Bitte LibreView-CSV prüfen."
        }

        parsed.sortBy { it.time }
        glucose.clear()
        glucose.addAll(parsed)
        persistGlucose()
        return "LibreView-Import erfolgreich: ${parsed.size} Glukosewerte"
    }

    private fun parseDate(text: String, formats: List<String>): Long? {
        for (pattern in formats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.GERMANY)
                sdf.isLenient = false
                return sdf.parse(text)?.time
            } catch (_: Exception) {
                // Try the next LibreView timestamp format.
            }
        }
        return null
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = ArrayList<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (quoted && i + 1 < line.length && line[i + 1] == '"') {
                        current.append('"')
                        i++
                    } else {
                        quoted = !quoted
                    }
                }
                c == ',' && !quoted -> {
                    result.add(current.toString())
                    current.setLength(0)
                }
                else -> current.append(c)
            }
            i++
        }
        result.add(current.toString())
        return result
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlucoPenApp(onNfc: ((Tag) -> Unit) -> Unit, onImportLibre: () -> Unit) {
    val vm = AppStore
    var tab by remember { mutableIntStateOf(0) }
    var showDose by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { onNfc { tag -> vm.nfcInfo = "NovoPen/NFC erkannt • " + tag.techList.joinToString(", ") { it.substringAfterLast(".") } } }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("GlucoPen 2.0") }) },
            bottomBar = {
                NavigationBar {
                    listOf("Übersicht", "Verlauf", "NFC", "Einstellungen").forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {},
                            label = { Text(t) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.padding(padding).padding(16.dp).fillMaxSize(),
                horizontalAlignment = Alignment.Start
            ) {
                when (tab) {
                    0 -> Dashboard(vm) { showDose = true }
                    1 -> History(vm)
                    2 -> NfcScreen(vm)
                    else -> SettingsScreen(onImportLibre)
                }
            }
        }

        if (showDose) {
            var units by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showDose = false },
                title = { Text("Insulin erfassen") },
                text = {
                    OutlinedTextField(
                        value = units,
                        onValueChange = { units = it },
                        label = { Text("Einheiten") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        units.toDoubleOrNull()?.let(vm::addDose)
                        showDose = false
                    }) { Text("Speichern") }
                },
                dismissButton = {
                    TextButton(onClick = { showDose = false }) { Text("Abbrechen") }
                }
            )
        }
    }
}

@Composable
fun Dashboard(vm: AppStore, add: () -> Unit) {
    val latest = vm.glucose.lastOrNull()?.value
    Text("Aktuelle Glukose", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text("${latest ?: "—"} mg/dL", style = MaterialTheme.typography.displaySmall)
    Spacer(Modifier.height(16.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Heute")
            Text("Insulin: %.1f E".format(vm.doses.sumOf { it.units }))
            Text("Messwerte: ${vm.glucose.size}")
        }
    }
    Spacer(Modifier.height(12.dp))
    Button(onClick = add, modifier = Modifier.fillMaxWidth()) {
        Text("Insulin manuell erfassen")
    }
    Spacer(Modifier.height(12.dp))
    Text(vm.status, style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(12.dp))
    Text(
        "Wichtig: Die angezeigten Werte sind Informationsdaten. GlucoPen ist nicht medizinisch validiert und ersetzt keine Therapieentscheidung.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
fun History(vm: AppStore) {
    var range by remember { mutableIntStateOf(0) }
    val now = System.currentTimeMillis()
    val cutoff = when (range) {
        0 -> now - 24L * 60 * 60 * 1000
        1 -> now - 7L * 24 * 60 * 60 * 1000
        2 -> now - 14L * 24 * 60 * 60 * 1000
        else -> now - 30L * 24 * 60 * 60 * 1000
    }
    val points = vm.glucose.filter { it.time >= cutoff }.sortedBy { it.time }
    val doses = vm.doses.filter { it.time >= cutoff }.sortedByDescending { it.time }
    val values = points.map { it.value }
    val average = values.takeIf { it.isNotEmpty() }?.average()
    val minimum = values.minOrNull()
    val maximum = values.maxOrNull()

    Text("Verlauf", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("24h", "7 Tage", "14 Tage", "30 Tage").forEachIndexed { i, label ->
            FilterChip(
                selected = range == i,
                onClick = { range = i },
                label = { Text(label) }
            )
        }
    }
    Spacer(Modifier.height(12.dp))

    if (points.isNotEmpty()) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Glukose + Insulin", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text("Insulingaben werden zeitlich direkt unter der Glukosekurve markiert.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                CombinedChart(points, doses)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Ø", "%.0f".format(average), "mg/dL", Modifier.weight(1f))
            StatCard("Min", "%.0f".format(minimum), "mg/dL", Modifier.weight(1f))
            StatCard("Max", "%.0f".format(maximum), "mg/dL", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Text("${points.size} Messwerte • ${doses.size} Insulingaben", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        if (doses.isNotEmpty()) {
            Text("Insulingaben", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.fillMaxWidth().height(190.dp)) {
                items(doses) { dose ->
                    val source = if (dose.source.startsWith("NovoPen")) "NovoPen" else "Manuell"
                    Text(
                        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(dose.time)) +
                            "  •  ${"%.1f".format(dose.units)} E  •  $source",
                        modifier = Modifier.padding(vertical = 5.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Text("Glukosewerte", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        LazyColumn(Modifier.fillMaxWidth().height(240.dp)) {
            items(points.takeLast(150).reversed()) { p ->
                Text(
                    SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(p.time)) +
                        "  •  ${"%.1f".format(p.value)} mg/dL",
                    modifier = Modifier.padding(vertical = 5.dp)
                )
            }
        }
    } else if (doses.isNotEmpty()) {
        Text("Keine Glukosewerte im gewählten Zeitraum.")
        Spacer(Modifier.height(12.dp))
        Text("Insulingaben", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.fillMaxWidth().height(300.dp)) {
            items(doses) { dose ->
                Text(
                    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(dose.time)) +
                        "  •  ${"%.1f".format(dose.units)} E  •  ${if (dose.source.startsWith("NovoPen")) "NovoPen" else "Manuell"}",
                    modifier = Modifier.padding(vertical = 5.dp)
                )
            }
        }
    } else {
        Text("Keine Daten im gewählten Zeitraum.")
    }
}

@Composable
fun CombinedChart(points: List<GlucosePoint>, doses: List<Dose>) {
    val shown = if (points.size > 500) {
        val step = points.size.toDouble() / 500.0
        List(500) { i -> points[min(points.lastIndex, (i * step).toInt())] }
    } else points
    val minValue = (shown.minOf { it.value } - 10).coerceAtLeast(40.0)
    val maxValue = (shown.maxOf { it.value } + 10).coerceAtLeast(minValue + 20.0)
    val low = shown.minOf { it.value }
    val high = shown.maxOf { it.value }
    val start = shown.first().time.toDouble()
    val end = shown.last().time.toDouble().coerceAtLeast(start + 1.0)
    val shownDoses = doses.filter { it.time >= start.toLong() && it.time <= end.toLong() }

    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${"%.0f".format(high)} mg/dL", style = MaterialTheme.typography.labelSmall)
            Text("${"%.0f".format(low)} mg/dL", style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(4.dp))
        Canvas(Modifier.fillMaxWidth().height(220.dp)) {
            val path = Path()
            shown.forEachIndexed { index, point ->
                val x = ((point.time - start) / (end - start) * size.width).toFloat()
                val y = (size.height - 18f - ((point.value - minValue) / (maxValue - minValue) * (size.height - 36f))).toFloat().coerceIn(18f, size.height - 18f)
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = Color(0xFF6D4CAF), style = Stroke(width = 5f))

            shownDoses.forEach { dose ->
                val x = ((dose.time - start) / (end - start) * size.width).toFloat().coerceIn(0f, size.width)
                drawLine(
                    color = Color(0xFFE65100),
                    start = androidx.compose.ui.geometry.Offset(x, size.height - 4f),
                    end = androidx.compose.ui.geometry.Offset(x, size.height - 55f),
                    strokeWidth = 5f
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("● Glukose", style = MaterialTheme.typography.labelSmall, color = Color(0xFF6D4CAF))
            Text("│ Insulin", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE65100))
        }
        if (shownDoses.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(
                shownDoses.takeLast(8).joinToString("   ") { "${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it.time))} ${"%.1f".format(it.units)} E" },
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

@Composable
fun StatCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(10.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(unit, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun GlucoseChart(points: List<GlucosePoint>) {
    val shown = if (points.size > 500) {
        val step = points.size.toDouble() / 500.0
        List(500) { i -> points[min(points.lastIndex, (i * step).toInt())] }
    } else points
    val minValue = min(40.0, (shown.minOf { it.value } - 10).coerceAtLeast(40.0))
    val maxValue = max(300.0, shown.maxOf { it.value } + 10)
    val low = shown.minOf { it.value }
    val high = shown.maxOf { it.value }
    val start = shown.first().time.toDouble()
    val end = shown.last().time.toDouble().coerceAtLeast(start + 1.0)

    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${"%.0f".format(high)} mg/dL", style = MaterialTheme.typography.labelSmall)
            Text("${"%.0f".format(low)} mg/dL", style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(4.dp))
        Canvas(Modifier.fillMaxWidth().height(190.dp)) {
            val path = Path()
            shown.forEachIndexed { index, point ->
                val x = ((point.time - start) / (end - start) * size.width).toFloat()
                val y = (size.height - ((point.value - minValue) / (maxValue - minValue) * size.height)).toFloat().coerceIn(0f, size.height)
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = Color(0xFF6D4CAF), style = Stroke(width = 5f))
        }
    }
}

@Composable
fun NfcScreen(vm: AppStore) {
    Text("NovoPen / NFC", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(12.dp))
    Text(vm.nfcInfo)
    Spacer(Modifier.height(12.dp))
    Text("Halte den NovoPen Echo Plus an die NFC-Stelle des Smartphones.")
    Spacer(Modifier.height(8.dp))
    Text(
        "GlucoPen liest NovoPen 6 / NovoPen Echo Plus über NFC und übernimmt die im Pen gespeicherten Insulingaben mit Datum/Uhrzeit. Die Daten dienen nur der Information und sind nicht für Therapieentscheidungen validiert.",
        style = MaterialTheme.typography.bodySmall
    )
    Spacer(Modifier.height(12.dp))
    Text("Insulingaben: ${vm.doses.count { it.source.startsWith("NovoPen") }}", style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun SettingsScreen(onImportLibre: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("de") }
    val ctx = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        val store = SecureStore(ctx)
        email = store.get("libre_email") ?: ""
        password = store.get("libre_password") ?: ""
        region = store.get("libre_region") ?: "de"
    }

    Text("Einstellungen", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(12.dp))
    Text(AppStore.libreStatus, style = MaterialTheme.typography.bodyMedium)
    Text(AppStore.libreLastSync, style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(email, { email = it }, label = { Text("LibreLinkUp E-Mail") }, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(password, { password = it }, label = { Text("LibreLinkUp Passwort") }, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(region, { region = it.lowercase().filter { c -> c.isLetterOrDigit() } }, label = { Text("Region (Deutschland: de)") }, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(10.dp))
    Button(onClick = {
        if (email.isBlank() || password.isBlank()) {
            AppStore.libreStatus = "Libre 3: E-Mail und Passwort eingeben"
        } else {
            SecureStore(ctx).put("libre_email", email)
            SecureStore(ctx).put("libre_password", password)
            SecureStore(ctx).put("libre_region", region.ifBlank { "de" })
            AppStore.libreStatus = "Libre 3: Verbindung wird getestet …"
            Thread({ LibreSyncWorker.syncNow(ctx) }, "GlucoPen-Libre-Sync").start()
        }
    }, modifier = Modifier.fillMaxWidth()) {
        Text("Libre 3 verbinden / jetzt synchronisieren")
    }
    Spacer(Modifier.height(8.dp))
    Button(onClick = onImportLibre, modifier = Modifier.fillMaxWidth()) {
        Text("LibreView CSV importieren")
    }
    Spacer(Modifier.height(12.dp))
    Text(
        "Die automatische Libre-Funktion nutzt die inoffizielle LibreLinkUp/LibreView-Cloud-Schnittstelle. Sie liest nicht direkt per Bluetooth aus dem Sensor. Dafür muss dein Libre 3 in der offiziellen Libre-App mit einem LibreLinkUp-Follower-Konto geteilt werden. Die Schnittstelle ist nicht von Abbott dokumentiert und kann sich ändern.",
        style = MaterialTheme.typography.bodySmall
    )
    Spacer(Modifier.height(8.dp))
    Text(
        "Das Passwort wird lokal verschlüsselt gespeichert. GlucoPen sendet die Zugangsdaten nur an den konfigurierten Libre-Server. Die Werte sind Informationsdaten und ersetzen keine Therapieentscheidung.",
        style = MaterialTheme.typography.bodySmall
    )
}

class SecureStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("glucopen_secure", Context.MODE_PRIVATE)
    private val alias = "GlucoPenSecureKey"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return generator.generateKey()
    }

    fun put(name: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        prefs.edit().putString("$name.data", encrypted).putString("$name.iv", iv).apply()
    }

    fun get(name: String): String? {
        return try {
            val data = prefs.getString("$name.data", null) ?: return null
            val iv = prefs.getString("$name.iv", null) ?: return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }
}

object LibreSyncWorker {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "glucopen_libre_sync", androidx.work.ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    fun syncNow(context: Context) {
        try {
            val store = SecureStore(context)
            val email = store.get("libre_email") ?: return
            val password = store.get("libre_password") ?: return
            val region = store.get("libre_region") ?: "de"
            val result = LibreApi.sync(email, password, region)
            AppStore.init(context)
            if (result.values.isNotEmpty()) {
                val arr = org.json.JSONArray()
                result.values.sortedBy { it.time }.forEach { p ->
                    arr.put(org.json.JSONObject().put("time", p.time).put("value", p.value))
                }
                context.getSharedPreferences("glucopen_data", Context.MODE_PRIVATE)
                    .edit().putString("glucose_json", arr.toString()).apply()
                Handler(Looper.getMainLooper()).post {
                    AppStore.glucose.clear()
                    AppStore.glucose.addAll(result.values.sortedBy { it.time })
                    AppStore.libreStatus = "Libre 3: verbunden • ${result.values.size} Werte"
                    AppStore.libreLastSync = "Letzte Synchronisation: ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date())}"
                }
            } else {
                Handler(Looper.getMainLooper()).post { AppStore.libreStatus = "Libre 3: keine Werte erhalten" }
            }
        } catch (e: Exception) {
            AppStore.init(context)
            AppStore.libreStatus = "Libre 3: Synchronisation fehlgeschlagen"
            AppStore.libreLastSync = e.message ?: "Unbekannter Fehler"
        }
    }
}

class SyncWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        LibreSyncWorker.syncNow(applicationContext)
        Result.success()
    }
}

object LibreApi {
    data class SyncResult(val values: List<GlucosePoint>)

    fun sync(email: String, password: String, region: String): SyncResult {
        var base = "https://api-$region.libreview.io"
        val loginBody = org.json.JSONObject().put("email", email).put("password", password).toString()
        var login = request("POST", "$base/llu/auth/login", loginBody, null, null)
        val loginJson = JSONObject(login)
        if (loginJson.optInt("status", -1) != 0) throw Exception(loginJson.optJSONObject("error")?.optString("message") ?: "Libre-Anmeldung abgelehnt")
        val data = loginJson.getJSONObject("data")
        val token = data.getJSONObject("authTicket").getString("token")
        val userId = data.getJSONObject("user").getString("id")
        val accountId = sha256(userId)

        val headers = mapOf("Authorization" to "Bearer $token", "Account-Id" to accountId)
        val connections = request("GET", "$base/llu/connections", null, headers, null)
        val arr = JSONObject(connections).getJSONArray("data")
        if (arr.length() == 0) throw Exception("Kein LibreLinkUp-Freigabekonto gefunden")
        val patientId = arr.getJSONObject(0).getString("patientId")
        val graph = request("GET", "$base/llu/connections/$patientId/graph", null, headers, null)
        val graphData = JSONObject(graph).getJSONObject("data").getJSONArray("graphData")
        val values = ArrayList<GlucosePoint>()
        for (i in 0 until graphData.length()) {
            val o = graphData.getJSONObject(i)
            val value = when {
                o.has("ValueInMgPerDl") -> o.optDouble("ValueInMgPerDl", 0.0)
                else -> o.optDouble("Value", 0.0)
            }
            val time = parseLibreTimestamp(o.optString("Timestamp"))
            if (time != null && value in 20.0..600.0) values.add(GlucosePoint(time, value))
        }
        val current = JSONObject(graph).getJSONObject("data").getJSONObject("connection").optJSONObject("glucoseMeasurement")
        if (current != null) {
            val value = current.optDouble("ValueInMgPerDl", current.optDouble("Value", 0.0))
            val time = parseLibreTimestamp(current.optString("Timestamp"))
            if (time != null && value in 20.0..600.0) values.add(GlucosePoint(time, value))
        }
        return SyncResult(values.distinctBy { it.time }.sortedBy { it.time }.takeLast(5000))
    }

    private fun request(method: String, url: String, body: String?, extra: Map<String,String>?, unused: Any?): String {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 20000
        conn.readTimeout = 20000
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("product", "llu.android")
        conn.setRequestProperty("version", "4.16.0")
        conn.setRequestProperty("User-Agent", "GlucoPen/2.0")
        extra?.forEach { (k,v) -> conn.setRequestProperty(k,v) }
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code: ${text.take(180)}")
        return text
    }

    private fun sha256(text: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private fun parseLibreTimestamp(text: String): Long? {
        val patterns = listOf("M/d/yyyy h:mm:ss a", "M/d/yyyy H:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        for (pattern in patterns) {
            try {
                val f = SimpleDateFormat(pattern, Locale.US)
                f.isLenient = false
                return f.parse(text)?.time
            } catch (_: Exception) { }
        }
        return null
    }
}
