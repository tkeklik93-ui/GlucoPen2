# GlucoPen 2.0

Android-App für Glukose- und Insulindaten.

## Funktionen
- FreeStyle Libre 3/3 Plus: optionale automatische Synchronisation über LibreLinkUp/LibreView-Cloud (inoffizielle, nicht dokumentierte Schnittstelle).
- LibreView CSV-Import.
- NovoPen Echo Plus / NovoPen 6 über NFC.
- Gemeinsamer Glukose-/Insulinverlauf.
- Automatische Libre-Synchronisation im Hintergrund (Android WorkManager, mindestens etwa alle 15 Minuten).

## Wichtig
Die Libre-Cloud-Anbindung ist **nicht offiziell von Abbott bereitgestellt oder unterstützt** und kann ohne Vorankündigung geändert werden. Sie liest den Sensor nicht direkt per Bluetooth. Für die Cloud-Synchronisation muss die Libre-App die Daten zu LibreLinkUp freigeben.

Die App ist nicht medizinisch validiert und ersetzt keine Therapieentscheidung.
