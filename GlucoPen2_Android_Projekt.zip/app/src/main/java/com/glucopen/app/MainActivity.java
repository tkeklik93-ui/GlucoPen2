package com.glucopen.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.nfc.*;
import android.nfc.tech.TagTechnology;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    static final int PICK_CSV = 42;
    ArrayList<Glucose> glucose = new ArrayList<>();
    ArrayList<Insulin> insulin = new ArrayList<>();
    LinearLayout root, content;
    TextView current, avg, lastInsulin, status, nfcStatus;
    GraphView graph;
    NfcAdapter nfc;

    int cyan = Color.rgb(84,216,238), purple = Color.rgb(123,63,242);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        load();
        buildUi();
        nfc = NfcAdapter.getDefaultAdapter(this);
        updateUi();
    }

    TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(18,12,18,12);
        return t;
    }

    GradientDrawable bg(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r); return g;
    }

    Button btn(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(bg(color, 24));
        return b;
    }

    void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(5,8,7));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18,14,18,18);
        ScrollView sv = new ScrollView(this); sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setPadding(8,6,8,6);
        nav.setBackgroundColor(Color.rgb(13,17,16));
        String[] tabs={"⌂  Übersicht","⌁  Verlauf","▣  NFC","⚙  Einstellungen"};
        for(String x:tabs){ Button b=btn(x,Color.TRANSPARENT); nav.addView(b,new LinearLayout.LayoutParams(0,64,1));
            if(x.contains("NFC")) b.setOnClickListener(v->showNfc());
            else if(x.contains("Verlauf")) b.setOnClickListener(v->showHistory());
            else if(x.contains("Einstellungen")) b.setOnClickListener(v->showSettings());
            else b.setOnClickListener(v->showDashboard());
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,72));
        setContentView(root);
        showDashboard();
    }

    void baseHeader(String title) {
        content.removeAllViews();
        TextView h=tv(title,24); h.setTypeface(null,1); content.addView(h);
        TextView warn=tv("⚠ Wichtiger medizinischer Hinweis\nGlucoPen 2.0 ist kein Medizinprodukt. Werte dienen ausschließlich der Information und ersetzen keine ärztliche Beratung.",13);
        warn.setTextColor(Color.rgb(230,220,190)); warn.setBackground(bg(Color.rgb(30,34,32),26));
        content.addView(warn);
    }

    void showDashboard() {
        baseHeader("GlucoPen 2.0");
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12,10,12,10);
        card.setBackground(bg(Color.rgb(10,16,14),28));
        current=tv("--",42); current.setTypeface(null,1); current.setTextColor(cyan); card.addView(tv("AKTUELLER GLUKOSEWERT",12)); card.addView(current);
        status=tv("Keine Daten – LibreView-CSV importieren oder Wert manuell erfassen.",13); status.setTextColor(Color.LTGRAY); card.addView(status);
        content.addView(card,lp(1,16));

        LinearLayout row=new LinearLayout(this);
        avg=tv("24h-DURCHSCHNITT\n-- mg/dL",16); lastInsulin=tv("LETZTE INSULINGABE\n-- E\nKeine Gabe erfasst",16);
        row.addView(panel(avg),new LinearLayout.LayoutParams(0,130,1)); row.addView(panel(lastInsulin),new LinearLayout.LayoutParams(0,130,1));
        content.addView(row);

        Button csv=btn("▣  Libre-CSV",cyan); csv.setTextColor(Color.BLACK);
        csv.setOnClickListener(v->pickCsv());
        Button pen=btn("▣  NovoPen",Color.rgb(55,86,91)); pen.setOnClickListener(v->showNfc());
        Button ins=btn("✚  Insulin",purple); ins.setOnClickListener(v->manualInsulin());
        Button glu=btn("💧  Glukose",Color.TRANSPARENT); glu.setOnClickListener(v->manualGlucose());
        LinearLayout r1=new LinearLayout(this); r1.addView(csv,new LinearLayout.LayoutParams(0,62,1)); r1.addView(pen,new LinearLayout.LayoutParams(0,62,1));
        LinearLayout r2=new LinearLayout(this); r2.addView(ins,new LinearLayout.LayoutParams(0,62,1)); r2.addView(glu,new LinearLayout.LayoutParams(0,62,1));
        content.addView(tv("SCHNELLZUGRIFF",12)); content.addView(r1); content.addView(r2);

        content.addView(tv("Glukose & Insulin (Letzte 24 Stunden)",20),lp(1,12));
        graph=new GraphView(this); content.addView(graph,new LinearLayout.LayoutParams(-1,300));
        updateUi();
    }

    LinearLayout panel(TextView t){ LinearLayout p=new LinearLayout(this); p.setPadding(6,4,6,4); p.setBackground(bg(Color.rgb(12,18,16),24)); p.addView(t); return p; }
    LinearLayout.LayoutParams lp(float w,int m){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT); p.setMargins(0,m,0,m); return p; }

    void updateUi(){
        if(current==null)return;
        if(glucose.size()>0){ Collections.sort(glucose,(a,b)->Long.compare(a.time,b.time)); Glucose g=glucose.get(glucose.size()-1); current.setText(String.format(Locale.US,"%.0f mg/dL",g.value)); status.setText("Letzte Messung: "+fmt(g.time)+"   •   "+glucose.size()+" Werte"); }
        double sum=0; long now=System.currentTimeMillis(), day=now-86400000L; int n=0;
        for(Glucose g:glucose) if(g.time>=day){sum+=g.value;n++;}
        avg.setText("24h-DURCHSCHNITT\n"+(n==0?"--":String.format(Locale.US,"%.0f mg/dL",sum/n)));
        if(insulin.size()>0){ Insulin i=insulin.get(insulin.size()-1); lastInsulin.setText(String.format(Locale.US,"LETZTE INSULINGABE\n%.1f E\n%s",i.units,fmt(i.time))); }
        if(graph!=null)graph.invalidate();
        save();
    }

    void pickCsv(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","application/csv","application/vnd.ms-excel"});
        startActivityForResult(i,PICK_CSV);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==PICK_CSV && c==RESULT_OK && d!=null && d.getData()!=null) importCsv(d.getData());
    }

    void importCsv(Uri uri){
        int added=0; long min=Long.MAX_VALUE,max=0;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
            String line; ArrayList<String> lines=new ArrayList<>();
            while((line=br.readLine())!=null) lines.add(line);
            if(lines.isEmpty()) throw new Exception("CSV ist leer");
            String header=lines.get(0).toLowerCase(Locale.ROOT);
            int timeCol=findCol(header,"timestamp","date","datum","time","zeit");
            int glucoseCol=findCol(header,"glucose","glukose","historic glucose","sensor glucose","mg/dl");
            if(timeCol<0||glucoseCol<0) throw new Exception("Keine passenden LibreView-Spalten gefunden");
            for(int k=1;k<lines.size();k++){
                String[] p=splitCsv(lines.get(k)); if(p.length<=Math.max(timeCol,glucoseCol))continue;
                Double val=parseNumber(p[glucoseCol]); Long tm=parseDate(p[timeCol]);
                if(val==null||tm==null||val<20||val>1000)continue;
                if(!exists(tm,val)){ glucose.add(new Glucose(tm,val)); added++; min=Math.min(min,tm); max=Math.max(max,tm); }
            }
            save(); updateUi();
            Toast.makeText(this,"Import erfolgreich: "+added+" neue Werte",Toast.LENGTH_LONG).show();
        }catch(Exception e){ Toast.makeText(this,"CSV-Import fehlgeschlagen: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    int findCol(String h,String... keys){
        String[] cols=h.split(","); for(int i=0;i<cols.length;i++){String x=cols[i].replace("\"","").trim(); for(String k:keys)if(x.contains(k))return i;} return -1;
    }
    String[] splitCsv(String s){ ArrayList<String>a=new ArrayList<>(); boolean q=false; StringBuilder b=new StringBuilder(); for(char ch:s.toCharArray()){if(ch=='"'){q=!q;continue;} if(ch==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(ch);}a.add(b.toString());return a.toArray(new String[0]); }
    Double parseNumber(String s){try{return Double.parseDouble(s.replace("\"","").trim().replace(",", "."));}catch(Exception e){return null;}}
    Long parseDate(String s){
        s=s.replace("\"","").trim();
        String[] fs={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm","dd.MM.yyyy HH:mm","MM/dd/yyyy HH:mm","yyyy-MM-dd'T'HH:mm:ss"};
        for(String f:fs)try{return new SimpleDateFormat(f,Locale.GERMANY).parse(s).getTime();}catch(Exception e){}
        try{return Long.parseLong(s);}catch(Exception e){return null;}
    }
    boolean exists(long t,double v){for(Glucose g:glucose)if(Math.abs(g.time-t)<60000 && Math.abs(g.value-v)<0.1)return true;return false;}
    String fmt(long t){return new SimpleDateFormat("dd.MM. HH:mm",Locale.GERMANY).format(new Date(t));}

    void manualGlucose(){
        EditText e=new EditText(this); e.setHint("Glukose mg/dL"); e.setInputType(2);
        new AlertDialog.Builder(this).setTitle("Glukose manuell erfassen").setView(e).setPositiveButton("Speichern",(d,w)->{Double v=parseNumber(e.getText().toString());if(v!=null){glucose.add(new Glucose(System.currentTimeMillis(),v));updateUi();}}).setNegativeButton("Abbrechen",null).show();
    }
    void manualInsulin(){
        EditText e=new EditText(this); e.setHint("Dosis in IE"); e.setInputType(2|8192);
        new AlertDialog.Builder(this).setTitle("Insulin manuell erfassen").setView(e).setPositiveButton("Speichern",(d,w)->{Double v=parseNumber(e.getText().toString());if(v!=null){insulin.add(new Insulin(System.currentTimeMillis(),v));updateUi();}}).setNegativeButton("Abbrechen",null).show();
    }

    void showHistory(){
        baseHeader("Verlauf");
        content.addView(tv("Glukosewerte: "+glucose.size()+"   •   Insulingaben: "+insulin.size(),16));
        for(int i=Math.max(0,glucose.size()-50);i<glucose.size();i++){Glucose g=glucose.get(i);content.addView(tv(fmt(g.time)+"   "+String.format(Locale.US,"%.0f mg/dL",g.value),14));}
    }

    void showNfc(){
        baseHeader("NFC / NovoPen");
        nfcStatus=tv("",18); content.addView(nfcStatus);
        if(nfc==null) nfcStatus.setText("NFC wird von diesem Gerät nicht unterstützt.");
        else if(!nfc.isEnabled()) nfcStatus.setText("NFC ist deaktiviert. Bitte NFC in den Android-Einstellungen aktivieren.");
        else nfcStatus.setText("NFC ist verfügbar.\n\nNoch nicht verbunden.\nHalte den NovoPen Echo Plus an die NFC-Stelle des Smartphones.\n\nHinweis: Das Auslesen der proprietären NovoPen-Dosisdaten ist noch nicht implementiert.");
        Button b=btn("NFC-Einstellungen öffnen",Color.rgb(55,86,91)); b.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NFC_SETTINGS))); content.addView(b);
    }

    void showSettings(){baseHeader("Einstellungen");content.addView(tv("GlucoPen 2.0 • Version 1.0",16));content.addView(tv("Daten werden lokal auf dem Gerät gespeichert.",14));content.addView(tv("CSV-Import: LibreView-Dateien\nNFC: Vorbereitung für NovoPen Echo Plus",14));}

    void save(){
        try{
            JSONArray g=new JSONArray(); for(Glucose x:glucose){JSONObject o=new JSONObject();o.put("t",x.time);o.put("v",x.value);g.put(o);}
            JSONArray i=new JSONArray(); for(Insulin x:insulin){JSONObject o=new JSONObject();o.put("t",x.time);o.put("u",x.units);i.put(o);}
            getPreferences(0).edit().putString("g",g.toString()).putString("i",i.toString()).apply();
        }catch(Exception e){}
    }
    void load(){
        try{JSONArray g=new JSONArray(getPreferences(0).getString("g","[]"));for(int k=0;k<g.length();k++){JSONObject o=g.getJSONObject(k);glucose.add(new Glucose(o.getLong("t"),o.getDouble("v")));}}
        catch(Exception e){}
        try{JSONArray i=new JSONArray(getPreferences(0).getString("i","[]"));for(int k=0;k<i.length();k++){JSONObject o=i.getJSONObject(k);insulin.add(new Insulin(o.getLong("t"),o.getDouble("u")));}}
        catch(Exception e){}
    }

    static class Glucose{long time;double value;Glucose(long t,double v){time=t;value=v;}}
    static class Insulin{long time;double units;Insulin(long t,double u){time=t;units=u;}}

    class GraphView extends View{
        Paint p=new Paint(1);
        GraphView(Context c){super(c);p.setStrokeWidth(4);}
        protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(Color.rgb(7,10,9));
            p.setColor(Color.rgb(0,90,55));p.setStyle(Paint.Style.STROKE);
            float y1=getHeight()*.25f,y2=getHeight()*.75f;c.drawLine(0,y1,getWidth(),y1,p);c.drawLine(0,y2,getWidth(),y2,p);
            if(glucose.size()<2)return; long max=glucose.get(glucose.size()-1).time,min=max-86400000L; p.setColor(cyan);p.setStyle(Paint.Style.STROKE);
            Path path=new Path();boolean first=true;for(Glucose g:glucose){if(g.time<min)continue;float x=(g.time-min)/(float)(max-min)*getWidth();float y=getHeight()-(float)Math.max(0,Math.min(400,g.value))/400f*getHeight();if(first){path.moveTo(x,y);first=false;}else path.lineTo(x,y);}c.drawPath(path,p);
        }
    }
}
