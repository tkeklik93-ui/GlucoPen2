# GlucoPen 2.0

Android-Projekt für Glukose-/Insulin-Dokumentation.

## Enthalten
- Dashboard
- LibreView-CSV-Import über Android Storage Access Framework
- Duplikaterkennung
- lokale Speicherung
- manuelle Glukose-/Insulineingabe
- Verlauf
- NFC-Statusseite
- GitHub Actions für automatischen APK-Build

## Wichtig
Die echte NovoPen Echo Plus-Dosisdaten-Decodierung ist in dieser Version noch nicht implementiert. NovoPen Echo Plus überträgt seine Dosisdaten per NFC an kompatible Apps; die konkrete Datenkommunikation ist proprietär und darf nicht durch erfundene Werte ersetzt werden.

Die App ist keine Therapie- oder Dosierungssoftware.
