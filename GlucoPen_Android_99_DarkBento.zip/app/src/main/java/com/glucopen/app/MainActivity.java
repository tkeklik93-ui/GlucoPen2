package com.glucopen.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.nfc.*;
import android.nfc.tech.TagTechnology;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    static final int PICK_CSV = 42;
    ArrayList<Glucose> glucose = new ArrayList<>();
    ArrayList<Insulin> insulin = new ArrayList<>();
    LinearLayout root, content;
    TextView current, avg, lastInsulin, status, nfcStatus;
    GraphView graph;
    NfcAdapter nfc;

    int cyan = Color.rgb(87, 220, 245), purple = Color.rgb(139, 92, 246), bg = Color.rgb(7, 9, 13), cardBg = Color.rgb(18, 21, 28), cardAlt = Color.rgb(24, 27, 36), muted = Color.rgb(156, 163, 175);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        load();
        buildUi();
        nfc = NfcAdapter.getDefaultAdapter(this);
        updateUi();
    }

    TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(18,12,18,12);
        return t;
    }

    GradientDrawable bg(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r); return g;
    }

    Button btn(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(bg(color, 24));
        return b;
    }

    void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18,18,18,24);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setPadding(10,8,10,8);
        nav.setBackgroundColor(Color.rgb(12,14,20));
        String[] tabs={"⌂\nÜbersicht","⌁\nVerlauf","▣\nNFC","⚙\nEinstellungen"};
        for(String x:tabs){
            Button b=btn(x,Color.TRANSPARENT); b.setTextColor(Color.rgb(190,194,205)); b.setTextSize(12);
            nav.addView(b,new LinearLayout.LayoutParams(0,70,1));
            if(x.contains("NFC")) b.setOnClickListener(v->showNfc());
            else if(x.contains("Verlauf")) b.setOnClickListener(v->showHistory());
            else if(x.contains("Einstellungen")) b.setOnClickListener(v->showSettings());
            else b.setOnClickListener(v->showDashboard());
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,78));
        setContentView(root);
        showDashboard();
    }

    void baseHeader(String title) {
        content.removeAllViews();
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=tv(title,28); h.setTypeface(null,1); h.setTextColor(Color.WHITE); h.setPadding(0,4,0,4);
        head.addView(h,new LinearLayout.LayoutParams(0,60,1));
        TextView dot=tv("●",18); dot.setTextColor(Color.rgb(70,220,150)); dot.setGravity(Gravity.CENTER); head.addView(dot,new LinearLayout.LayoutParams(40,60));
        content.addView(head);
        TextView sub=tv("Deine Glukose- und Insulindaten auf einen Blick",14); sub.setTextColor(muted); sub.setPadding(0,0,0,12); content.addView(sub);
    }

    LinearLayout bentoCard() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(18,16,18,16); c.setBackground(bg(cardBg,26));
        return c;
    }

    TextView label(String s) { TextView t=tv(s.toUpperCase(Locale.ROOT),11); t.setTypeface(null,1); t.setTextColor(muted); t.setLetterSpacing(.08f); return t; }

    void showDashboard() {
        baseHeader("GlucoPen 2.0");

        LinearLayout hero=bentoCard();
        TextView l=label("Aktueller Glukosewert"); hero.addView(l);
        current=tv("--",44); current.setTypeface(null,1); current.setTextColor(cyan); current.setPadding(0,4,0,0); hero.addView(current);
        status=tv("Noch keine Messdaten",13); status.setTextColor(muted); status.setPadding(0,5,0,0); hero.addView(status);
        content.addView(hero,lp(1,4));

        LinearLayout row=new LinearLayout(this); row.setPadding(0,10,0,0);
        avg=tv("24h\n-- mg/dL",17); avg.setTypeface(null,1);
        lastInsulin=tv("Insulin\n-- E",17); lastInsulin.setTypeface(null,1);
        LinearLayout a=bentoCard(); a.addView(label("24h-Durchschnitt")); a.addView(avg);
        LinearLayout b=bentoCard(); b.addView(label("Letzte Insulingabe")); b.addView(lastInsulin);
        row.addView(a,new LinearLayout.LayoutParams(0,142,1)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,142,1); bp.setMargins(10,0,0,0); row.addView(b,bp); content.addView(row);

        content.addView(label("Schnellzugriff"),lp(1,18));
        LinearLayout r1=new LinearLayout(this), r2=new LinearLayout(this);
        Button csv=btn("▣  Libre-CSV",Color.rgb(55,211,190)); csv.setTextColor(Color.rgb(4,20,19)); csv.setOnClickListener(v->pickCsv());
        Button pen=btn("▣  NovoPen",cardAlt); pen.setTextColor(Color.WHITE); pen.setOnClickListener(v->showNfc());
        Button ins=btn("✚  Insulin",purple); ins.setOnClickListener(v->manualInsulin());
        Button glu=btn("＋  Glukose",cardAlt); glu.setTextColor(Color.WHITE); glu.setOnClickListener(v->manualGlucose());
        r1.addView(csv,new LinearLayout.LayoutParams(0,62,1)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,62,1); pp.setMargins(10,0,0,0); r1.addView(pen,pp);
        r2.addView(ins,new LinearLayout.LayoutParams(0,62,1)); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,62,1); gp.setMargins(10,0,0,0); r2.addView(glu,gp);
        content.addView(r1); content.addView(r2,lp(1,10));

        LinearLayout graphCard=bentoCard(); TextView gl=tv("Glukoseverlauf",19); gl.setTypeface(null,1); graphCard.addView(gl); TextView gs=tv("Letzte 24 Stunden",12); gs.setTextColor(muted); graphCard.addView(gs);
        graph=new GraphView(this); graphCard.addView(graph,new LinearLayout.LayoutParams(-1,280)); content.addView(graphCard,lp(1,18));

        TextView note=tv("INFORMATION\nDie App dient nur zur Anzeige und Dokumentation. Keine Therapie- oder Dosisempfehlungen.",12); note.setTextColor(muted); note.setPadding(4,8,4,8); content.addView(note);
        updateUi();
    }

    LinearLayout panel(TextView t){ LinearLayout p=bentoCard(); p.addView(t); return p; }
    LinearLayout.LayoutParams lp(float w,int m){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT); p.setMargins(0,m,0,m); return p; }

    void updateUi(){
        if(current==null)return;
        if(glucose.size()>0){ Collections.sort(glucose,(a,b)->Long.compare(a.time,b.time)); Glucose g=glucose.get(glucose.size()-1); current.setText(String.format(Locale.US,"%.0f mg/dL",g.value)); status.setText("Letzte Messung: "+fmt(g.time)+"   •   "+glucose.size()+" Werte"); }
        double sum=0; long now=System.currentTimeMillis(), day=now-86400000L; int n=0;
        for(Glucose g:glucose) if(g.time>=day){sum+=g.value;n++;}
        avg.setText("24h\n"+(n==0?"--":String.format(Locale.US,"%.0f mg/dL",sum/n))+" mg/dL");
        if(insulin.size()>0){ Insulin i=insulin.get(insulin.size()-1); lastInsulin.setText(String.format(Locale.US,"%.1f E\n%s",i.units,fmt(i.time))); }
        if(graph!=null)graph.invalidate();
        save();
    }

    void pickCsv(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","application/csv","application/vnd.ms-excel"});
        startActivityForResult(i,PICK_CSV);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==PICK_CSV && c==RESULT_OK && d!=null && d.getData()!=null) importCsv(d.getData());
    }

    void importCsv(Uri uri){
        int added=0; long min=Long.MAX_VALUE,max=0;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
            String line; ArrayList<String> lines=new ArrayList<>();
            while((line=br.readLine())!=null) lines.add(line);
            if(lines.isEmpty()) throw new Exception("CSV ist leer");
            String header=lines.get(0).toLowerCase(Locale.ROOT);
            int timeCol=findCol(header,"timestamp","date","datum","time","zeit");
            int glucoseCol=findCol(header,"glucose","glukose","historic glucose","sensor glucose","mg/dl");
            if(timeCol<0||glucoseCol<0) throw new Exception("Keine passenden LibreView-Spalten gefunden");
            for(int k=1;k<lines.size();k++){
                String[] p=splitCsv(lines.get(k)); if(p.length<=Math.max(timeCol,glucoseCol))continue;
                Double val=parseNumber(p[glucoseCol]); Long tm=parseDate(p[timeCol]);
                if(val==null||tm==null||val<20||val>1000)continue;
                if(!exists(tm,val)){ glucose.add(new Glucose(tm,val)); added++; min=Math.min(min,tm); max=Math.max(max,tm); }
            }
            save(); updateUi();
            Toast.makeText(this,"Import erfolgreich: "+added+" neue Werte",Toast.LENGTH_LONG).show();
        }catch(Exception e){ Toast.makeText(this,"CSV-Import fehlgeschlagen: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    int findCol(String h,String... keys){
        String[] cols=h.split(","); for(int i=0;i<cols.length;i++){String x=cols[i].replace("\"","").trim(); for(String k:keys)if(x.contains(k))return i;} return -1;
    }
    String[] splitCsv(String s){ ArrayList<String>a=new ArrayList<>(); boolean q=false; StringBuilder b=new StringBuilder(); for(char ch:s.toCharArray()){if(ch=='"'){q=!q;continue;} if(ch==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(ch);}a.add(b.toString());return a.toArray(new String[0]); }
    Double parseNumber(String s){try{return Double.parseDouble(s.replace("\"","").trim().replace(",", "."));}catch(Exception e){return null;}}
    Long parseDate(String s){
        s=s.replace("\"","").trim();
        String[] fs={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm","dd.MM.yyyy HH:mm","MM/dd/yyyy HH:mm","yyyy-MM-dd'T'HH:mm:ss"};
        for(String f:fs)try{return new SimpleDateFormat(f,Locale.GERMANY).parse(s).getTime();}catch(Exception e){}
        try{return Long.parseLong(s);}catch(Exception e){return null;}
    }
    boolean exists(long t,double v){for(Glucose g:glucose)if(Math.abs(g.time-t)<60000 && Math.abs(g.value-v)<0.1)return true;return false;}
    String fmt(long t){return new SimpleDateFormat("dd.MM. HH:mm",Locale.GERMANY).format(new Date(t));}

    void manualGlucose(){
        EditText e=new EditText(this); e.setHint("Glukose mg/dL"); e.setInputType(2);
        new AlertDialog.Builder(this).setTitle("Glukose manuell erfassen").setView(e).setPositiveButton("Speichern",(d,w)->{Double v=parseNumber(e.getText().toString());if(v!=null){glucose.add(new Glucose(System.currentTimeMillis(),v));updateUi();}}).setNegativeButton("Abbrechen",null).show();
    }
    void manualInsulin(){
        EditText e=new EditText(this); e.setHint("Dosis in IE"); e.setInputType(2|8192);
        new AlertDialog.Builder(this).setTitle("Insulin manuell erfassen").setView(e).setPositiveButton("Speichern",(d,w)->{Double v=parseNumber(e.getText().toString());if(v!=null){insulin.add(new Insulin(System.currentTimeMillis(),v));updateUi();}}).setNegativeButton("Abbrechen",null).show();
    }

    void showHistory(){
        baseHeader("Verlauf");
        content.addView(tv("Glukosewerte: "+glucose.size()+"   •   Insulingaben: "+insulin.size(),16));
        for(int i=Math.max(0,glucose.size()-50);i<glucose.size();i++){Glucose g=glucose.get(i);content.addView(tv(fmt(g.time)+"   "+String.format(Locale.US,"%.0f mg/dL",g.value),14));}
    }

    void showNfc(){
        baseHeader("NFC / NovoPen");
        nfcStatus=tv("",18); content.addView(nfcStatus);
        if(nfc==null) nfcStatus.setText("NFC wird von diesem Gerät nicht unterstützt.");
        else if(!nfc.isEnabled()) nfcStatus.setText("NFC ist deaktiviert. Bitte NFC in den Android-Einstellungen aktivieren.");
        else nfcStatus.setText("NFC ist verfügbar.\n\nNoch nicht verbunden.\nHalte den NovoPen Echo Plus an die NFC-Stelle des Smartphones.\n\nHinweis: Das Auslesen der proprietären NovoPen-Dosisdaten ist noch nicht implementiert.");
        Button b=btn("NFC-Einstellungen öffnen",Color.rgb(55,86,91)); b.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NFC_SETTINGS))); content.addView(b);
    }

    void showSettings(){baseHeader("Einstellungen");content.addView(tv("GlucoPen 2.0 • Version 1.0",16));content.addView(tv("Daten werden lokal auf dem Gerät gespeichert.",14));content.addView(tv("CSV-Import: LibreView-Dateien\nNFC: Vorbereitung für NovoPen Echo Plus",14));}

    void save(){
        try{
            JSONArray g=new JSONArray(); for(Glucose x:glucose){JSONObject o=new JSONObject();o.put("t",x.time);o.put("v",x.value);g.put(o);}
            JSONArray i=new JSONArray(); for(Insulin x:insulin){JSONObject o=new JSONObject();o.put("t",x.time);o.put("u",x.units);i.put(o);}
            getPreferences(0).edit().putString("g",g.toString()).putString("i",i.toString()).apply();
        }catch(Exception e){}
    }
    void load(){
        try{JSONArray g=new JSONArray(getPreferences(0).getString("g","[]"));for(int k=0;k<g.length();k++){JSONObject o=g.getJSONObject(k);glucose.add(new Glucose(o.getLong("t"),o.getDouble("v")));}}
        catch(Exception e){}
        try{JSONArray i=new JSONArray(getPreferences(0).getString("i","[]"));for(int k=0;k<i.length();k++){JSONObject o=i.getJSONObject(k);insulin.add(new Insulin(o.getLong("t"),o.getDouble("u")));}}
        catch(Exception e){}
    }

    static class Glucose{long time;double value;Glucose(long t,double v){time=t;value=v;}}
    static class Insulin{long time;double units;Insulin(long t,double u){time=t;units=u;}}

    class GraphView extends View{
        Paint p=new Paint(1);
        GraphView(Context c){super(c);p.setStrokeWidth(4);}
        protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(Color.rgb(18,21,28));
            p.setColor(Color.rgb(48,55,68));p.setStyle(Paint.Style.STROKE);
            float y1=getHeight()*.25f,y2=getHeight()*.75f;c.drawLine(0,y1,getWidth(),y1,p);c.drawLine(0,y2,getWidth(),y2,p);
            if(glucose.size()<2)return; long max=glucose.get(glucose.size()-1).time,min=max-86400000L; p.setColor(cyan);p.setStyle(Paint.Style.STROKE);
            Path path=new Path();boolean first=true;for(Glucose g:glucose){if(g.time<min)continue;float x=(g.time-min)/(float)(max-min)*getWidth();float y=getHeight()-(float)Math.max(0,Math.min(400,g.value))/400f*getHeight();if(first){path.moveTo(x,y);first=false;}else path.lineTo(x,y);}c.drawPath(path,p);
        }
    }
}
