# GlucoPen 1.6

Android-App zur informativen Zusammenführung von LibreView-CSV-Glukosedaten und NovoPen 6 / NovoPen Echo Plus NFC-Daten.

## Neu in 1.6
- NovoPen 6 / NovoPen Echo Plus NFC-Lesen über `nvplib` 0.2.0.
- Übernahme der im Pen gespeicherten Insulingaben mit Zeitstempel und Einheiten.
- Anzeige von Pen-Modell/Seriennummer und Anzahl importierter Insulingaben.
- LibreView CSV-Import und Glukosekurve bleiben erhalten.

## Hinweis
Die NovoPen-NFC-Anbindung nutzt die Open-Source-Bibliothek `net.cacheux.nvplib` (Apache-2.0). Die App ist nicht von Novo Nordisk entwickelt oder endorsed und ist nicht medizinisch validiert. Daten nur zu Informationszwecken verwenden und Therapieentscheidungen nicht daraus ableiten.
