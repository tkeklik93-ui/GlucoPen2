package de.glucopen.app

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*

data class GlucosePoint(val time: Long, val value: Double)
data class Dose(val time: Long, val units: Double, val source: String)

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    private var onTagDetected: ((Tag) -> Unit)? = null

    private val csvPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    val count = AppStore.importLibreCsv(text)
                    AppStore.status = "LibreView-Import: $count Glukosewerte"
                }
            } catch (e: Exception) {
                AppStore.status = "CSV konnte nicht gelesen werden"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        setContent {
            GlucoPenApp(
                onNfc = { onTagDetected = it },
                onImportLibre = { csvPicker.launch(arrayOf("text/*", "text/csv", "application/csv")) }
            )
        }
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        nfcAdapter?.let { adapter ->
            if (adapter.isEnabled) {
                adapter.enableForegroundDispatch(this, pendingIntent, null, null)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_TECH_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action) {
            intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)?.let {
                AppStore.nfcInfo = describeTag(it)
                onTagDetected?.invoke(it)
            }
        }
    }

    private fun describeTag(tag: Tag): String {
        val tech = tag.techList.joinToString(", ") { it.substringAfterLast(".") }
        return "NFC erkannt • $tech"
    }
}

object AppStore {
    val glucose = mutableStateListOf(
        GlucosePoint(System.currentTimeMillis() - 30 * 60_000L, 119.0),
        GlucosePoint(System.currentTimeMillis() - 15 * 60_000L, 121.0),
        GlucosePoint(System.currentTimeMillis(), 119.0)
    )
    val doses = mutableStateListOf<Dose>()
    var nfcInfo by mutableStateOf("Noch kein NFC-Gerät erkannt")
    var status by mutableStateOf("Bereit")

    fun addDose(units: Double) {
        doses.add(Dose(System.currentTimeMillis(), units, "Manuell"))
        status = "Insulin gespeichert"
    }

    fun importLibreCsv(csv: String): Int {
        var added = 0
        val lines = csv.lineSequence().toList()
        for ((index, line) in lines.withIndex()) {
            if (index == 0 || line.isBlank()) continue
            val sep = if (line.count { it == ';' } > line.count { it == ',' }) ';' else ','
            val parts = line.split(sep)
            if (parts.size < 2) continue

            val value = parts.firstNotNullOfOrNull { token ->
                token.trim().replace("\"", "").replace(",", ".").toDoubleOrNull()
            } ?: continue

            if (value in 20.0..600.0) {
                glucose.add(GlucosePoint(System.currentTimeMillis() - added * 60_000L, value))
                added++
            }
        }
        return added
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlucoPenApp(onNfc: ((Tag) -> Unit) -> Unit, onImportLibre: () -> Unit) {
    val vm = AppStore
    var tab by remember { mutableIntStateOf(0) }
    var showDose by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { onNfc { tag -> vm.nfcInfo = "NovoPen/NFC erkannt • " + tag.techList.joinToString(", ") { it.substringAfterLast(".") } } }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("GlucoPen 1.3") }) },
            bottomBar = {
                NavigationBar {
                    listOf("Übersicht", "Verlauf", "NFC", "Einstellungen").forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {},
                            label = { Text(t) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.padding(padding).padding(16.dp).fillMaxSize(),
                horizontalAlignment = Alignment.Start
            ) {
                when (tab) {
                    0 -> Dashboard(vm) { showDose = true }
                    1 -> History(vm)
                    2 -> NfcScreen(vm)
                    else -> SettingsScreen(onImportLibre)
                }
            }
        }

        if (showDose) {
            var units by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showDose = false },
                title = { Text("Insulin erfassen") },
                text = {
                    OutlinedTextField(
                        value = units,
                        onValueChange = { units = it },
                        label = { Text("Einheiten") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        units.toDoubleOrNull()?.let(vm::addDose)
                        showDose = false
                    }) { Text("Speichern") }
                },
                dismissButton = {
                    TextButton(onClick = { showDose = false }) { Text("Abbrechen") }
                }
            )
        }
    }
}

@Composable
fun Dashboard(vm: AppStore, add: () -> Unit) {
    val latest = vm.glucose.lastOrNull()?.value
    Text("Aktuelle Glukose", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text("${latest ?: "—"} mg/dL", style = MaterialTheme.typography.displaySmall)
    Spacer(Modifier.height(16.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Heute")
            Text("Insulin: %.1f E".format(vm.doses.sumOf { it.units }))
            Text("Messwerte: ${vm.glucose.size}")
        }
    }
    Spacer(Modifier.height(12.dp))
    Button(onClick = add, modifier = Modifier.fillMaxWidth()) {
        Text("Insulin manuell erfassen")
    }
    Spacer(Modifier.height(12.dp))
    Text(vm.status, style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(12.dp))
    Text(
        "Wichtig: Die angezeigten Werte sind Informationsdaten. GlucoPen ist nicht medizinisch validiert und ersetzt keine Therapieentscheidung.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
fun History(vm: AppStore) {
    Text("Verlauf", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    LazyColumn {
        items(vm.glucose.takeLast(100).reversed()) { p ->
            Text(
                SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(p.time)) +
                    "  •  ${"%.1f".format(p.value)} mg/dL",
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }
    }
}

@Composable
fun NfcScreen(vm: AppStore) {
    Text("NovoPen / NFC", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(12.dp))
    Text(vm.nfcInfo)
    Spacer(Modifier.height(12.dp))
    Text("Halte den NovoPen Echo Plus an die NFC-Stelle des Smartphones.")
    Spacer(Modifier.height(8.dp))
    Text(
        "Version 1.3 erkennt NFC-Tags. Die proprietären NovoPen-Dosisdaten werden noch nicht automatisch als Insulinwerte übernommen.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
fun SettingsScreen(onImportLibre: () -> Unit) {
    Text("Einstellungen", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(16.dp))
    Button(onClick = onImportLibre, modifier = Modifier.fillMaxWidth()) {
        Text("LibreView CSV importieren")
    }
    Spacer(Modifier.height(12.dp))
    Text("Der Import ist für exportierte LibreView-Glukosedaten gedacht.", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(12.dp))
    Text("Direkter Zugriff auf Libre 3/3 Plus und automatische NovoPen-Dekodierung sind in dieser Version noch nicht freigeschaltet.", style = MaterialTheme.typography.bodySmall)
}
