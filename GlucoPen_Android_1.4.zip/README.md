# GlucoPen 1.4

Android-Projekt für eine Informations-App rund um Glukose- und Insulindaten.

## Neu in 1.4
- Android NFC Foreground Dispatch
- Erkennung eines NFC-Tags, z.B. beim Anhalten eines NovoPen Echo Plus
- Robuster LibreView-CSV/TSV-Import mit Erkennung von Zeitstempel sowie Historic/Scan Glukose
- Unterstützung von mg/dL und mmol/L beim LibreView-Import
- Zusammenführung der importierten Glukosewerte in den Verlauf
- Bestehende manuelle Insulinerfassung bleibt erhalten

## Wichtige Einschränkungen
Diese Version liest noch keine proprietären NovoPen-Dosisdaten aus dem NFC-Tag aus und greift nicht direkt auf einen FreeStyle Libre 3/3 Plus Sensor zu.
Die Glukosedaten können über einen LibreView-Export importiert werden.

Die App ist nicht medizinisch validiert und darf nicht für Dosierungsentscheidungen verwendet werden.
