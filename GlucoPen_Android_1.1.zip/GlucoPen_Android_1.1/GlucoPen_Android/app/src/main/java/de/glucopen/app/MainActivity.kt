package de.glucopen.app

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    private var nfcCallback: ((Tag) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        pendingIntent = PendingIntent.getActivity(this, 0, Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_MUTABLE)
        setContent { GlucoPenApp { tag -> readTag(tag) } }
        intent?.let { if (NfcAdapter.ACTION_TAG_DISCOVERED == it.action || NfcAdapter.ACTION_TECH_DISCOVERED == it.action || NfcAdapter.ACTION_NDEF_DISCOVERED == it.action) it.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)?.let(::readTag) }
    }
    private fun readTag(tag: Tag) { nfcCallback?.invoke(tag) }
    fun setNfcCallback(cb: (Tag)->Unit) { nfcCallback = cb }
    override fun onResume() { super.onResume(); nfcAdapter?.enableForegroundDispatch(this, pendingIntent, null, null) }
    override fun onPause() { nfcAdapter?.disableForegroundDispatch(this); super.onPause() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)?.let(::readTag) }
}

data class Glucose(val time: Long, val value: Double)
data class InsulinDose(val time: Long, val units: Double, val source: String)

class AppVM : androidx.lifecycle.ViewModel() {
    var glucose by mutableStateOf(listOf(Glucose(System.currentTimeMillis()-3600000, 112.0), Glucose(System.currentTimeMillis()-1800000, 126.0), Glucose(System.currentTimeMillis(), 119.0)))
        private set
    var doses by mutableStateOf(listOf<InsulinDose>())
        private set
    var nfcStatus by mutableStateOf("NFC bereit")
        private set
    fun onNfc(tag: Tag) { nfcStatus = "NFC-Gerät erkannt: ${tag.techList.firstOrNull()?.substringAfterLast('.') ?: "unbekannt"}" }
    fun addDose(units: Double) { doses = doses + InsulinDose(System.currentTimeMillis(), units, "Manuell") }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GlucoPenApp(onTag: (Tag)->Unit) {
    val vm: AppVM = viewModel()
    var tab by remember { mutableIntStateOf(0) }
    var showDose by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { onTag.let { /* callback wired by Activity in production */ } }
    MaterialTheme {
        Scaffold(topBar={ TopAppBar(title={Text("GlucoPen")}) }, bottomBar={ NavigationBar { listOf("Übersicht","Verlauf","NFC","Einstellungen").forEachIndexed { i,t -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={},label={Text(t)}) } } }) { p ->
            Column(Modifier.padding(p).padding(16.dp).fillMaxSize()) {
                when(tab) {
                    0 -> Dashboard(vm, { showDose=true })
                    1 -> History(vm)
                    2 -> NfcScreen(vm)
                    else -> SettingsScreen()
                }
            }
        }
        if(showDose) { var units by remember { mutableStateOf("") }; AlertDialog(onDismissRequest={showDose=false}, title={Text("Insulin erfassen")}, text={ OutlinedTextField(value=units,onValueChange={units=it},label={Text("Einheiten")}) }, confirmButton={ TextButton(onClick={units.toDoubleOrNull()?.let(vm::addDose);showDose=false}){Text("Speichern")} }, dismissButton={TextButton(onClick={showDose=false}){Text("Abbrechen")}}) }
    }
}

@Composable fun Dashboard(vm: AppVM, add:()->Unit) { val latest=vm.glucose.lastOrNull()?.value; Text("Aktuelle Glukose", style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(8.dp)); Text("${latest ?: "—"} mg/dL", style=MaterialTheme.typography.displaySmall); Spacer(Modifier.height(16.dp)); Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Heute");Text("Insulin: %.1f E".format(vm.doses.sumOf{it.units}));Text("Messwerte: ${vm.glucose.size}")}};Spacer(Modifier.height(12.dp));Button(onClick=add,modifier=Modifier.fillMaxWidth()){Text("Insulin manuell erfassen")};Spacer(Modifier.height(12.dp));Text("Hinweis: Glukosewerte dienen der Anzeige und ersetzen keine medizinische Entscheidung.",style=MaterialTheme.typography.bodySmall)}
@Composable fun History(vm: AppVM){LazyColumn{items(vm.glucose.reversed()){g->Text("${SimpleDateFormat("HH:mm",Locale.GERMANY).format(Date(g.time))}  ${g.value} mg/dL",Modifier.padding(8.dp))};items(vm.doses.reversed()){d->Text("${SimpleDateFormat("HH:mm",Locale.GERMANY).format(Date(d.time))}  ${d.units} E (${d.source})",Modifier.padding(8.dp))}}}
@Composable fun NfcScreen(vm: AppVM){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()){Text("NovoPen Echo Plus",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));Text("${vm.nfcStatus}");Spacer(Modifier.height(16.dp));Text("Halte den Pen an die NFC-Antenne des Smartphones.");Spacer(Modifier.height(12.dp));Text("Diese Version erkennt NFC-Tags. Die proprietäre NovoPen-Datenstruktur wird erst nach einer autorisierten/technisch verifizierten Schnittstelle dekodiert.",style=MaterialTheme.typography.bodySmall)}}
@Composable fun SettingsScreen(){Text("Einstellungen",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));Text("GlucoPen 1.0\nAndroid 8.0+\nNFC-Unterstützung erforderlich für Pen-Auslesung.")}
