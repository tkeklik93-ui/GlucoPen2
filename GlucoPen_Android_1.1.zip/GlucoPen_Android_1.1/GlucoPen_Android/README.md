# GlucoPen – Android

Android-Projekt für eine gemeinsame Diabetes-Datenansicht.

## Enthalten
- Material-3 Android-Oberfläche
- Dashboard und Verlauf
- lokale Insulin-Einträge
- NFC-Erkennung als Grundlage für NovoPen Echo Plus
- klare Trennung der Geräteadapter
- GitHub Actions Workflow zum automatischen Debug-APK-Build

## Wichtige technische Grenze
Abbott stellt keine frei dokumentierte öffentliche API zur direkten Einbettung der Libre-3-Sensorauslesung in beliebige Apps bereit. Abbott nennt LibreView als Cloud-/Datenfreigabeweg. Dieses Projekt verwendet deshalb keine Reverse-Engineering-Login-Implementierung und behauptet keine medizinische Geräteintegration, die nicht offiziell freigegeben ist.

Die NovoPen-Echo-Plus-NFC-Dekodierung benötigt eine verifizierte Protokollimplementierung; reine NFC-Tag-Erkennung ist enthalten.

## APK ohne PC
Das Repository kann auf GitHub hochgeladen werden. Danach startet `.github/workflows/android.yml` einen Build und erzeugt `app-debug.apk` als Artifact.
