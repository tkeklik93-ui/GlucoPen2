# GlucoPen 1.5 – LibreView CSV Import Fix

Diese Version bleibt in der App sichtbar **1.5**.

Der LibreView-Import sucht die tatsächliche CSV-Kopfzeile und liest die Spalten:
- Gerätezeitstempel / Device Timestamp
- Glukosewert-Verlauf mg/dL / Historic Glucose
- Glukose-Scan mg/dL / Scan Glucose

Die Demo-Glukosewerte werden nach einem erfolgreichen Import durch die importierten LibreView-Werte ersetzt.

Hinweis: GlucoPen ist nicht medizinisch validiert. Die Daten dienen nur der Information und ersetzen keine Therapieentscheidung.


## Verlauf 1.5
- Glukosekurve für 24h, 7, 14 und 30 Tage
- Durchschnitt, Minimum und Maximum im gewählten Zeitraum
- Liste der letzten 150 Werte
